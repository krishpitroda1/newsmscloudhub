<?php

function sms_is_optout($phone){

global $wpdb;

$table=$wpdb->prefix.'sms_optout';

$row=$wpdb->get_row($wpdb->prepare(
"SELECT * FROM $table WHERE phone=%s",$phone
));

return $row ? true : false;

}