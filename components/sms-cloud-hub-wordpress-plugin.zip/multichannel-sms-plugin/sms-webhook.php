<?php

add_action('rest_api_init','sms_register_webhook');

function sms_register_webhook(){

register_rest_route(
'multichannel-sms/v1',
'/delivery',
[
'methods' => 'POST',
'callback' => 'sms_receive_delivery_report',
'permission_callback' => '__return_true'
]
);

}

function sms_receive_delivery_report($request){

global $wpdb;

$table = $wpdb->prefix.'sms_logs';

$data = $request->get_json_params();

if(empty($data)){
return [
'status' => 'error',
'message' => 'No data received'
];
}

$reference = sanitize_text_field($data['reference_id']);
$status = sanitize_text_field($data['status']);

$wpdb->update(
$table,
['status'=>$status],
['reference_id'=>$reference]
);

return [
'status' => 'success'
];

}