<?php

add_action('admin_menu','sms_menu');

function sms_menu(){

add_menu_page(
'SMS Dashboard',
'SMS Plugin',
'manage_options',
'sms-plugin',
'sms_dashboard_page'
);

add_submenu_page(
'sms-plugin',
'SMS Dashboard',
'SMS Dashboard',
'manage_options',
'sms-plugin',
'sms_dashboard_page'
);

add_submenu_page(
'sms-plugin',
'SMS Settings',
'Settings',
'manage_options',
'sms-settings',
'sms_settings_page'
);

add_submenu_page(
'sms-plugin',
'Send SMS',
'Send SMS',
'manage_options',
'send-sms',
'sms_send_page'
);

add_submenu_page(
'sms-plugin',
'Templates',
'Templates',
'manage_options',
'sms-templates',
'sms_templates_page'
);

add_submenu_page(
'sms-plugin',
'Bulk SMS',
'Bulk SMS',
'manage_options',
'bulk-sms',
'sms_bulk_page'
);

add_submenu_page(
'sms-plugin',
'SMS Logs',
'SMS Logs',
'manage_options',
'sms-logs',
'sms_logs_page'
);

}

function sms_settings_page(){

if(isset($_POST['sms_base_url'])){

update_option('sms_base_url',sanitize_text_field($_POST['sms_base_url']));
update_option('sms_api_token',sanitize_text_field($_POST['sms_api_token']));

update_option('sms_template_user_registration',sanitize_text_field($_POST['sms_template_user_registration']));
update_option('sms_template_order_placed',sanitize_text_field($_POST['sms_template_order_placed']));
update_option('sms_template_order_completed',sanitize_text_field($_POST['sms_template_order_completed']));

}

?>

<div class="wrap">

<h1 style="margin-bottom:20px;">SMS Settings</h1>

<style>

.sms-settings-card{
background:#ffffff;
padding:30px;
border-radius:12px;
box-shadow:0 3px 12px rgba(0,0,0,0.08);
max-width:700px;
margin-bottom:25px;
}

.sms-field{
margin-bottom:20px;
}

.sms-field label{
display:block;
font-weight:600;
margin-bottom:6px;
}

.sms-input{
width:100%;
padding:10px;
border:1px solid #dcdcdc;
border-radius:6px;
font-size:14px;
}

.sms-section-title{
font-size:18px;
font-weight:600;
margin-bottom:15px;
}

.sms-save-btn{
background:#4f46e5;
color:white;
border:none;
padding:12px 20px;
border-radius:6px;
font-size:15px;
cursor:pointer;
}

.sms-save-btn:hover{
background:#4338ca;
}

</style>

<form method="post">

<div class="sms-settings-card">

<div class="sms-section-title">API Configuration</div>

<div class="sms-field">
<label>Base URL</label>
<input type="text"
name="sms_base_url"
class="sms-input"
value="<?php echo esc_attr(get_option('sms_base_url')); ?>">
</div>

<div class="sms-field">
<label>API Token</label>
<input type="text"
name="sms_api_token"
class="sms-input"
value="<?php echo esc_attr(get_option('sms_api_token')); ?>">
</div>

</div>


<div class="sms-settings-card">

<div class="sms-section-title">Automation Templates</div>

<div class="sms-field">
<label>User Registration Template ID</label>
<input type="text"
name="sms_template_user_registration"
class="sms-input"
value="<?php echo esc_attr(get_option('sms_template_user_registration')); ?>">
</div>

<div class="sms-field">
<label>Order Placed Template ID</label>
<input type="text"
name="sms_template_order_placed"
class="sms-input"
value="<?php echo esc_attr(get_option('sms_template_order_placed')); ?>">
</div>

<div class="sms-field">
<label>Order Completed Template ID</label>
<input type="text"
name="sms_template_order_completed"
class="sms-input"
value="<?php echo esc_attr(get_option('sms_template_order_completed')); ?>">
</div>

</div>

<button class="sms-save-btn">Save Settings</button>

</form>

</div>

<?php
}