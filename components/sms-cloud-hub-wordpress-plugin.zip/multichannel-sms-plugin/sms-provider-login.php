<?php

function sms_provider_login_page(){

$register_url="http://cpaas.smscloudhub.info/";

if(isset($_POST['connect_sms'])){

$api_key = sanitize_text_field($_POST['api_key']);

/* temporarily store key to test */
update_option('sms_api_token',$api_key);

/* call API test function */
$connected = sms_api_test_connection();

if($connected){

echo "<div class='updated'><p>Connected to SMSCloudHub successfully.</p></div>";

}else{

delete_option('sms_api_token');

echo "<div class='error'><p>Invalid API Key. Please check your key.</p></div>";

}

}

?>

<div class="wrap">

<h1>Connect SMS Provider</h1>

<p>Paste your SMSCloudHub API key from your CPaaS dashboard.</p>

<form method="post">

<input type="text" name="api_key" placeholder="Enter API Key" style="width:400px" required>

<br><br>

<button class="button button-primary" name="connect_sms">
Connect Account
</button>

</form>

<br>

<a class="button" target="_blank" href="<?php echo $register_url; ?>">
Create SMSCloudHub Account
</a>

</div>

<?php
}