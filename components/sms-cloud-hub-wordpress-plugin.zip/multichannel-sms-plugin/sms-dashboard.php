<?php

function sms_dashboard_page(){

/* show login page if not connected */

if(!sms_provider_connected()){

echo "<div class='wrap'><h1>Connect your SMS Provider account first.</h1></div>";

sms_provider_login_page();

return;

}

/* get balance from API */

$balance_data = sms_api_get_balance();

$balance = "Unknown";

if(isset($balance_data['available'])){
$balance = $balance_data['available'];
}

global $wpdb;

$table = $wpdb->prefix.'sms_logs';

$total = $wpdb->get_var("SELECT COUNT(*) FROM $table");
$delivered = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status='delivered'");
$failed = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status='failed'");
$today = $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE DATE(created_at)=CURDATE()");

?>

<div class="wrap">

<h1 style="margin-bottom:20px;">SMS Dashboard</h1>

<style>

.sms-dashboard-grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
gap:20px;
margin-top:20px;
max-width:1000px;
}

.sms-card{
background:#ffffff;
border-radius:12px;
padding:25px;
box-shadow:0 3px 12px rgba(0,0,0,0.08);
transition:0.2s;
}

.sms-card:hover{
transform:translateY(-3px);
box-shadow:0 6px 18px rgba(0,0,0,0.12);
}

.sms-title{
font-size:14px;
color:#777;
margin-bottom:10px;
}

.sms-value{
font-size:32px;
font-weight:600;
color:#111;
}

.sms-balance{
background:linear-gradient(135deg,#6366f1,#4f46e5);
color:white;
}

.sms-balance .sms-title{
color:#e0e7ff;
}

.sms-balance .sms-value{
color:white;
}

</style>

<div class="sms-dashboard-grid">

<div class="sms-card sms-balance">
<div class="sms-title">SMS Balance</div>
<div class="sms-value"><?php echo esc_html($balance); ?></div>
</div>

<div class="sms-card">
<div class="sms-title">Total SMS Sent</div>
<div class="sms-value"><?php echo esc_html($total); ?></div>
</div>

<div class="sms-card">
<div class="sms-title">Delivered</div>
<div class="sms-value"><?php echo esc_html($delivered); ?></div>
</div>

<div class="sms-card">
<div class="sms-title">Failed</div>
<div class="sms-value"><?php echo esc_html($failed); ?></div>
</div>

<div class="sms-card">
<div class="sms-title">Sent Today</div>
<div class="sms-value"><?php echo esc_html($today); ?></div>
</div>

</div>

</div>

<?php
}