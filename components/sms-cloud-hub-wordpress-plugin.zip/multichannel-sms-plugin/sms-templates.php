<?php

function sms_templates_page(){

if(!sms_provider_connected()){
return;
}

/* fetch templates from API */
$templates = sms_api_get_templates();

?>

<div class="wrap">

<h1 style="margin-bottom:20px;">SMS Templates</h1>

<style>

.sms-table-card{
background:#ffffff;
padding:25px;
border-radius:12px;
box-shadow:0 3px 12px rgba(0,0,0,0.08);
max-width:1100px;
}

.sms-table{
width:100%;
border-collapse:collapse;
}

.sms-table th{
text-align:left;
padding:12px;
border-bottom:1px solid #eee;
font-weight:600;
background:#f9fafb;
}

.sms-table td{
padding:12px;
border-bottom:1px solid #f1f1f1;
vertical-align:top;
}

.sms-content{
max-width:420px;
line-height:1.4;
color:#444;
}

.sms-status{
padding:4px 10px;
border-radius:20px;
font-size:12px;
font-weight:600;
display:inline-block;
}

.sms-approved{
background:#ecfdf5;
color:#059669;
}

.sms-pending{
background:#fff7ed;
color:#d97706;
}

.sms-rejected{
background:#fef2f2;
color:#dc2626;
}

</style>

<div class="sms-table-card">

<table class="sms-table">

<thead>
<tr>
<th>Template ID</th>
<th>Template Name</th>
<th>Sender ID</th>
<th>Status</th>
<th>Content</th>
</tr>
</thead>

<tbody>

<?php

if(!empty($templates)){

foreach($templates as $t){

$status_class = "sms-pending";

if(strtolower($t['status']) == "approved"){
$status_class = "sms-approved";
}

if(strtolower($t['status']) == "rejected"){
$status_class = "sms-rejected";
}

echo "<tr>";

echo "<td>".esc_html($t['template_id'])."</td>";
echo "<td>".esc_html($t['template_name'])."</td>";
echo "<td>".esc_html($t['sender_id'])."</td>";

echo "<td>
<span class='sms-status ".$status_class."'>
".esc_html($t['status'])."
</span>
</td>";

echo "<td class='sms-content'>".esc_html($t['content'])."</td>";

echo "</tr>";

}

}else{

echo "<tr><td colspan='5'>No templates found.</td></tr>";

}

?>

</tbody>

</table>

</div>

</div>

<?php
}