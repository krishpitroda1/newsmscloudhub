<?php

function sms_bulk_page(){

if(!sms_provider_connected()){
return;
}

$success = false;
$error = false;

if(isset($_POST['upload_csv'])){

$template = sanitize_text_field($_POST['template']);

$numbers = [];

if(isset($_FILES['csv_file']['tmp_name'])){

$file = fopen($_FILES['csv_file']['tmp_name'], "r");

while(($row = fgetcsv($file)) !== FALSE){

if(isset($row[0]) && !empty($row[0])){
$numbers[] = trim($row[0]);
}

}

fclose($file);

}

/* send SMS via API */
$response = sms_api_send_sms($numbers,$template);

if(isset($response['success']) && $response['success']==true){
$success = true;
}else{
$error = true;
}

}

/* fetch templates */
$templates = sms_api_get_templates();

?>

<div class="wrap">

<h1 style="margin-bottom:20px;">Bulk SMS</h1>

<style>

.sms-card{
background:#ffffff;
padding:30px;
border-radius:12px;
box-shadow:0 3px 12px rgba(0,0,0,0.08);
max-width:650px;
}

.sms-field{
margin-bottom:20px;
}

.sms-field label{
display:block;
font-weight:600;
margin-bottom:6px;
}

.sms-input{
width:100%;
padding:10px;
border:1px solid #dcdcdc;
border-radius:6px;
font-size:14px;
}

.sms-upload{
border:2px dashed #d1d5db;
padding:30px;
text-align:center;
border-radius:8px;
background:#fafafa;
}

.sms-upload input{
margin-top:10px;
}

.sms-help{
font-size:13px;
color:#666;
margin-top:8px;
}

.sms-button{
background:#4f46e5;
color:white;
border:none;
padding:12px 20px;
border-radius:6px;
font-size:15px;
cursor:pointer;
transition:0.2s;
}

.sms-button:hover{
background:#4338ca;
}

.sms-success{
background:#ecfdf5;
border-left:4px solid #10b981;
padding:12px;
margin-bottom:20px;
border-radius:6px;
}

.sms-error{
background:#fef2f2;
border-left:4px solid #ef4444;
padding:12px;
margin-bottom:20px;
border-radius:6px;
}

</style>

<?php if($success){ ?>

<div class="sms-success">
Bulk SMS sent successfully.
</div>

<?php } ?>

<?php if($error){ ?>

<div class="sms-error">
Bulk SMS sending failed.
</div>

<?php } ?>

<div class="sms-card">

<form method="post" enctype="multipart/form-data">

<div class="sms-field">

<label>Upload CSV File</label>

<div class="sms-upload">

Upload your CSV file containing phone numbers.

<br>

<input type="file" name="csv_file" accept=".csv" required>

<div class="sms-help">
CSV format example:<br>
9876543210<br>
9123456789<br>
9898989898
</div>

</div>

</div>


<div class="sms-field">

<label>Select Template</label>

<select name="template" class="sms-input">

<?php

if(!empty($templates)){

foreach($templates as $t){

echo "<option value='".$t['template_id']."'>".$t['template_name']."</option>";

}

}

?>

</select>

</div>


<button class="sms-button" name="upload_csv">
Send Bulk SMS
</button>

</form>

</div>

</div>

<?php
}