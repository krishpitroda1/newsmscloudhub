<?php
function sms_send_page(){

if(!sms_provider_connected()){
return;
}

$success = false;
$error = false;

if(isset($_POST['phone'])){

$phone = sanitize_text_field($_POST['phone']);
$template = sanitize_text_field($_POST['template']);

$numbers = [$phone];

/* send SMS using API */
$response = sms_api_send_sms($numbers,$template);

if(isset($response['success']) && $response['success']==true){
$success = true;
}else{
$error = true;
}

}

/* fetch templates from API */
$templates = sms_api_get_templates();

?>

<div class="wrap">

<h1 style="margin-bottom:20px;">Send SMS</h1>

<style>

.sms-form-card{
background:#ffffff;
padding:30px;
border-radius:12px;
box-shadow:0 3px 12px rgba(0,0,0,0.08);
max-width:600px;
}

.sms-field{
margin-bottom:20px;
}

.sms-field label{
display:block;
font-weight:600;
margin-bottom:6px;
}

.sms-input{
width:100%;
padding:10px;
border:1px solid #dcdcdc;
border-radius:6px;
font-size:14px;
}

.sms-button{
background:#4f46e5;
color:white;
border:none;
padding:12px 20px;
border-radius:6px;
font-size:15px;
cursor:pointer;
transition:0.2s;
}

.sms-button:hover{
background:#4338ca;
}

.sms-success{
background:#ecfdf5;
border-left:4px solid #10b981;
padding:12px;
margin-bottom:20px;
border-radius:6px;
}

.sms-error{
background:#fef2f2;
border-left:4px solid #ef4444;
padding:12px;
margin-bottom:20px;
border-radius:6px;
}

</style>

<?php if($success){ ?>

<div class="sms-success">
SMS sent successfully.
</div>

<?php } ?>

<?php if($error){ ?>

<div class="sms-error">
SMS sending failed.
</div>

<?php } ?>

<div class="sms-form-card">

<form method="post">

<div class="sms-field">

<label>Phone Number</label>

<input 
type="text"
name="phone"
class="sms-input"
placeholder="Enter phone number (e.g. 9876543210)"
required
>

</div>


<div class="sms-field">

<label>Select Template</label>

<select name="template" class="sms-input">

<?php

if(!empty($templates)){

foreach($templates as $t){

echo "<option value='".$t['template_id']."'>".$t['template_name']."</option>";

}

}

?>

</select>

</div>

<button class="sms-button">Send SMS</button>

</form>

</div>

</div>

<?php
}