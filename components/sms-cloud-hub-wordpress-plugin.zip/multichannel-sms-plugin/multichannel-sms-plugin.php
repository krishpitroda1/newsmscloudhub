<?php
/*
/*
Plugin Name: SMSCloudHub WordPress SMS
Description: Send SMS, Bulk SMS and automated WooCommerce SMS using SMSCloudHub CPaaS.
Version: 1.0
Author: Rank First Digital
*/

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'sms-optout.php';
require_once plugin_dir_path(__FILE__) . 'sms-triggers.php';
require_once plugin_dir_path(__FILE__) . 'sms-dashboard.php';
require_once plugin_dir_path(__FILE__) . 'sms-provider-login.php';
require_once plugin_dir_path(__FILE__) . 'sms-api.php';
require_once plugin_dir_path(__FILE__) . 'sms-settings.php';
require_once plugin_dir_path(__FILE__) . 'sms-send.php';
require_once plugin_dir_path(__FILE__) . 'sms-templates.php';
require_once plugin_dir_path(__FILE__) . 'sms-logs.php';
require_once plugin_dir_path(__FILE__) . 'sms-bulk.php';
require_once plugin_dir_path(__FILE__) . 'sms-webhook.php';	
register_activation_hook(__FILE__, 'sms_create_logs_table');

function sms_provider_connected(){

$token=get_option('sms_api_token');

if(!$token){

echo "<div class='wrap'>
<h2>Connect your SMS Provider account first.</h2>
<p>Please login from Dashboard.</p>
</div>";

return false;

}

return true;

}
function sms_create_logs_table(){

global $wpdb;

$table = $wpdb->prefix.'sms_logs';

$sql = "CREATE TABLE $table (
id INT AUTO_INCREMENT,
phone VARCHAR(20),
status VARCHAR(50),
reference_id VARCHAR(200),
created_at DATETIME,
PRIMARY KEY(id)
)";

require_once(ABSPATH.'wp-admin/includes/upgrade.php');
dbDelta($sql);

}

register_activation_hook(__FILE__, 'sms_plugin_create_tables');

function sms_plugin_create_tables(){

global $wpdb;

$charset_collate = $wpdb->get_charset_collate();

$logs_table = $wpdb->prefix.'sms_logs';
$optout_table = $wpdb->prefix.'sms_optout';

require_once(ABSPATH.'wp-admin/includes/upgrade.php');

$sql1 = "CREATE TABLE $logs_table (
id INT AUTO_INCREMENT,
phone VARCHAR(20),
status VARCHAR(50),
reference_id VARCHAR(200),
created_at DATETIME,
PRIMARY KEY(id)
) $charset_collate;";

$sql2 = "CREATE TABLE $optout_table (
id INT AUTO_INCREMENT,
phone VARCHAR(20),
created_at DATETIME,
PRIMARY KEY(id)
) $charset_collate;";

dbDelta($sql1);
dbDelta($sql2);

}

add_action('sms_check_delivery','sms_update_delivery_status');

if(!wp_next_scheduled('sms_check_delivery')){
wp_schedule_event(time(), 'five_minutes', 'sms_check_delivery');
}

add_filter('cron_schedules','sms_add_cron');

function sms_add_cron($schedules){

$schedules['five_minutes']=[
'interval'=>300,
'display'=>'Every Five Minutes'
];

return $schedules;

}