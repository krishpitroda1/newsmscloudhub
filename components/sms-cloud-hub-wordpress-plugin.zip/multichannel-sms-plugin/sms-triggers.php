<?php

/* USER REGISTRATION SMS */

add_action('user_register','sms_send_user_registration_sms');

function sms_send_user_registration_sms($user_id){

if(!sms_provider_connected()){
return;
}

$template_id = get_option('sms_template_user_registration');

if(!$template_id){
return;
}

$user = get_userdata($user_id);

$phone = get_user_meta($user_id,'billing_phone',true);

if(!$phone){
return;
}

$numbers = [$phone];

sms_api_send_sms($numbers,$template_id);

}



/* ORDER PLACED SMS */

add_action('woocommerce_checkout_order_processed','sms_send_order_sms');

function sms_send_order_sms($order_id){

if(!sms_provider_connected()){
return;
}

$template_id = get_option('sms_template_order_placed');

if(!$template_id){
return;
}

$order = wc_get_order($order_id);

$phone = $order->get_billing_phone();

if(!$phone){
return;
}

$numbers = [$phone];

sms_api_send_sms($numbers,$template_id);

}



/* ORDER COMPLETED SMS */

add_action('woocommerce_order_status_completed','sms_order_completed_sms');

function sms_order_completed_sms($order_id){

if(!sms_provider_connected()){
return;
}

$template_id = get_option('sms_template_order_completed');

if(!$template_id){
return;
}

$order = wc_get_order($order_id);

$phone = $order->get_billing_phone();

if(!$phone){
return;
}

$numbers = [$phone];

sms_api_send_sms($numbers,$template_id);

}