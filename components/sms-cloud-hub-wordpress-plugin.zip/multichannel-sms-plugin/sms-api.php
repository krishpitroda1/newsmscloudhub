<?php

function sms_api_base(){
return "http://cpaas.smscloudhub.info/api/v1";
}

function sms_api_token(){
return get_option('sms_api_token');
}

function sms_api_headers(){

return [
'Authorization' => 'Bearer '.sms_api_token(),
'Content-Type' => 'application/json'
];

}


/* TEST API CONNECTION */

function sms_api_test_connection(){

$url = sms_api_base()."/credit";

$response = wp_remote_get($url,[
'headers'=>sms_api_headers(),
'timeout'=>20
]);

if(is_wp_error($response)){
return false;
}

$code = wp_remote_retrieve_response_code($response);

return ($code == 200);

}


/* GET SMS TEMPLATES */

function sms_api_get_templates(){

$url = sms_api_base()."/sms/templates";

$response = wp_remote_get($url,[
'headers'=>sms_api_headers(),
'timeout'=>20
]);

if(is_wp_error($response)){
return [];
}

$body = wp_remote_retrieve_body($response);
$data = json_decode($body,true);

if(isset($data['data']) && is_array($data['data'])){
return $data['data'];
}

return [];

}


/* SEND SMS */

function sms_api_send_sms($numbers,$template_id){

global $wpdb;

$url = sms_api_base()."/sms/sendMessage";

$payload = [
"template_id"=>$template_id,
"numbers"=>$numbers,
"unicode"=>0,
"personalized"=>0
];

$response = wp_remote_post($url,[
'headers'=>sms_api_headers(),
'body'=>json_encode($payload),
'timeout'=>20
]);

if(is_wp_error($response)){
return false;
}

$body = wp_remote_retrieve_body($response);
$data = json_decode($body,true);


/* Extract reference id if returned */

$reference_id = '';

if(isset($data['reference_id'])){
$reference_id = $data['reference_id'];
}

if(isset($data['data']['reference_id'])){
$reference_id = $data['data']['reference_id'];
}


/* SAVE SMS LOG */

$table = $wpdb->prefix.'sms_logs';

foreach($numbers as $phone){

$wpdb->insert(
$table,
[
'phone' => sanitize_text_field($phone),
'reference_id' => $reference_id,
'status' => 'submitted',
'created_at' => current_time('mysql')
]
);

}

return $data;

}


/* DELIVERY REPORT */

function sms_api_get_delivery_report($reference_id){

$url = sms_api_base()."/sms/reports/".$reference_id;

$response = wp_remote_get($url,[
'headers'=>sms_api_headers(),
'timeout'=>20
]);

if(is_wp_error($response)){
return false;
}

$body = wp_remote_retrieve_body($response);
$data = json_decode($body,true);

return $data;

}


/* SMS BALANCE */

function sms_api_get_balance(){

$url = sms_api_base()."/credit";

$response = wp_remote_get($url,[
'headers'=>sms_api_headers(),
'timeout'=>20
]);

if(is_wp_error($response)){
return false;
}

$body = wp_remote_retrieve_body($response);
$data = json_decode($body,true);

return $data;

}