<?php

function sms_logs_page(){

if(!sms_provider_connected()){
return;
}

global $wpdb;

$table = $wpdb->prefix.'sms_logs';

/* refresh delivery status if requested */

if(isset($_GET['check'])){

$ref = sanitize_text_field($_GET['check']);

if(!empty($ref)){

$report = sms_api_get_delivery_report($ref);

if(!empty($report) && is_array($report)){

foreach($report as $r){

if(isset($r['status'])){

$wpdb->update(
$table,
['status'=>$r['status']],
['reference_id'=>$ref]
);

}

}

echo "<div class='notice notice-success'><p>Status updated successfully.</p></div>";

}else{

echo "<div class='notice notice-error'><p>Unable to fetch delivery report.</p></div>";

}

}

}

/* fetch logs */

$logs = $wpdb->get_results("SELECT * FROM $table ORDER BY id DESC");

?>

<div class="wrap">

<h1 style="margin-bottom:20px;">SMS Delivery Reports</h1>

<style>

.sms-table-card{
background:#ffffff;
padding:25px;
border-radius:12px;
box-shadow:0 3px 12px rgba(0,0,0,0.08);
max-width:1100px;
}

.sms-table{
width:100%;
border-collapse:collapse;
}

.sms-table th{
text-align:left;
padding:12px;
border-bottom:1px solid #eee;
background:#f9fafb;
font-weight:600;
}

.sms-table td{
padding:12px;
border-bottom:1px solid #f1f1f1;
}

.sms-status{
padding:4px 10px;
border-radius:20px;
font-size:12px;
font-weight:600;
display:inline-block;
}

.sms-delivered{
background:#ecfdf5;
color:#059669;
}

.sms-submitted{
background:#eef2ff;
color:#4338ca;
}

.sms-failed{
background:#fef2f2;
color:#dc2626;
}

.sms-refresh-btn{
background:#4f46e5;
color:white;
padding:6px 12px;
border-radius:6px;
text-decoration:none;
font-size:12px;
}

.sms-refresh-btn:hover{
background:#4338ca;
color:white;
}

</style>

<div class="sms-table-card">

<table class="sms-table">

<thead>
<tr>
<th>ID</th>
<th>Phone</th>
<th>Status</th>
<th>Reference ID</th>
<th>Date</th>
<th>Check Status</th>
</tr>
</thead>

<tbody>

<?php

if(!empty($logs)){

foreach($logs as $log){

$status_class = "sms-submitted";

if(strtolower($log->status) == "delivered"){
$status_class = "sms-delivered";
}

if(strtolower($log->status) == "failed"){
$status_class = "sms-failed";
}

echo "<tr>";

echo "<td>".esc_html($log->id)."</td>";
echo "<td>".esc_html($log->phone)."</td>";

echo "<td>
<span class='sms-status ".$status_class."'>
".esc_html($log->status)."
</span>
</td>";

echo "<td>".esc_html($log->reference_id)."</td>";
echo "<td>".esc_html($log->created_at)."</td>";

echo "<td>";

if(!empty($log->reference_id)){

echo "<a class='sms-refresh-btn' href='?page=sms-logs&check=".esc_attr($log->reference_id)."'>
Refresh
</a>";

}else{

echo "-";

}

echo "</td>";

echo "</tr>";

}

}else{

echo "<tr><td colspan='6'>No logs found</td></tr>";

}

?>

</tbody>

</table>

</div>

</div>

<?php
}